data = [ 290, 1012, 731, 801, 992, 1395, 367, 519, 795, 1385, 274, 154, 219, 1410, 83, 589, 553, 362, 594, 851, 173,
657, 581, 397, 543, 791, 226, 81, 1459, 126, 941, 491, 1207, 1093, 1473, 951, 267, 1371, 864, 953, 1119, 212, 1266,
120, 723, 643, 205, 130, 9, 16, 1053, 507, 1381, 1122, 1323, 758, 713, 1219, 375, 951, 98, 1011, 642, 1099, 1098, 453, 7, 1137, 53, 1352, 553, 380, 1324, 473, 519, 923, 13, 592, 10, 546, 65, 1440, 1002, 1444, 510, 1266, 901, 1444, 691, 650, 373, 896, 681, 916, 943, 323, 783, 1385, 891, 621, 687, 1384, 268, 211, 708, 1067, 736, 1223, 990, 1145, 448, 731, 486, 381, 1441, 312, 181, 785, 157, 793, 1029, 1273, 846, 1473, 57, 785, 588, 582, 920, 808, 644, 1182, 1101, 579, 623, 556, 858, 59, 163, 1236, 310, 1308, 962, 356, 1005, 883, 582, 786, 958, 321]

def bubbleSort(mylist):
   mylist = mylist.copy()
   n = len(mylist)
   swapKecil = 0

   for i in range(n-1):
      swapped = False

      for j in range(n-i-1):
         if mylist[j] > mylist[j+1]:
            mylist[j], mylist[j+1] = mylist[j+1], mylist[j]
            swapKecil += 1
            swapped = True

      if not swapped:
         break

   return mylist, swapKecil

def selectionSort(mylist):
   mylist = mylist.copy()
   n = len(mylist)
   swappedBesar = 0

   for i in range(n-1):
      max_index = i

      for j in range(i+1, n):
         if mylist[j] > mylist[max_index]:
            max_index = j

      if max_index != i:
         mylist[i], mylist[max_index] = mylist[max_index], mylist[i]
         swappedBesar += 1

   return mylist, swappedBesar

      



bubble_sort, bubble_swaps = bubbleSort(data)
print('Bubble Sort (kecil → besar): ')
print('Jumlah swap Bubble Sort: ', bubble_swaps)

selection_sort, selection_swaps = selectionSort(data)
print('Selection Sort (besar → kecil: )')
print('Jumlah swap Selection Sort: ', selection_swaps)